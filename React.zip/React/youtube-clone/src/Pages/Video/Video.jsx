import React from 'react'
import './Video.css'

const Video = () => {
  return (
    <div>

    </div>
  )
}

export default Video
